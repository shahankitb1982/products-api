let map;

function initMap() {
  map = new google.maps.Map(document.getElementById("map"), {
    zoom: 2,
    center: new google.maps.LatLng(2.8, -187.3),
    mapTypeId: "terrain",
  });
  // Create a <script> tag and set the USGS URL as the source.
  const script = document.createElement("script");
  script.src =
    "http://earthquake.usgs.gov/earthquakes/feed/v1.0/summary/all_day.geojsonp";
  document.getElementsByTagName("head")[0].appendChild(script);
}

// Loop through the results array and place a marker for each set of coordinates.
const eqfeed_callback = function (results) {
  if (results.features.length > 0) {
    for (let i = 0; i < results.features.length; i++) {
      const coords = results.features[i].geometry.coordinates;
      const properties = results.features[i].properties;
      const latLng = new google.maps.LatLng(coords[1], coords[0]);
      const marker = new google.maps.Marker({
        position: latLng,
        map: map,
      });

     const dateObject = new Date(properties.time)

     const formattedDateTime = dateObject.toLocaleString("en-US", {timeZoneName: "short"})

     // Content for Info Window.
     const contentString = 
      '<div id="content">' +
      '<h3 id="firstHeading" class="firstHeading">'+properties.title+'</h3>' +
      '<div id="bodyContent">' +
      '<p>Time : '+formattedDateTime+'</p>' +
      '<p>Latitude : '+coords[1]+'</p>' +
      '<p>Longitude : '+coords[0]+'</p>' +
      '</div>' +
      '</div>';

      const infowindow = new google.maps.InfoWindow({
         content: contentString,
      });

      marker.addListener("click", () => {
        infowindow.open({
          anchor: marker,
          map,
          shouldFocus: false,
        });
      });

      // To make infowindow responsive
      google.maps.event.addDomListener(window, 'resize', function() {
            infowindow.open(map);
      });
    }
  }
};

// Show the earthquake data (Title, Magnitude, URL, Location) in a table and sort by the strongest magnitude first.
const today = new Date();
const formattedTodayDate = today.toISOString().slice(0, 10);
const yesterday = new Date(today)
yesterday.setDate(today.getDate() - 1);
const formattedYesterdayDate = yesterday.toISOString().slice(0, 10);

const dataUrl = "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&starttime="+formattedYesterdayDate+"&endtime="+formattedTodayDate+"&orderby=magnitude";
//console.log( "URL: " + dataUrl );
$.getJSON( dataUrl, function( resultsData ) {
   if (resultsData.features.length > 0) {
     var htmlData = '<h4>Earthquakes data sorted by the strongest magnitude first</h4>';
     htmlData += "<table>";
     for (let i = 0; i < resultsData.features.length; i++) {
       const coords = resultsData.features[i].geometry.coordinates;
       const properties = resultsData.features[i].properties;

       htmlData += "<tr>";
       htmlData += "<th>"+properties.mag+"</th>";
       htmlData += "<td><strong>"+properties.title+"</strong><br />"+properties.url+"<br />"+coords[1]+","+coords[0]+"</td>";
       htmlData += "</td>";
       htmlData += "</tr>";
    }
    htmlData += "</table>";
    $( "#mapData" ).html(htmlData);
    var table = document.querySelector("table");
    table.className = "tableData";
  }
});
